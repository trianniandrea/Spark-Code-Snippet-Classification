# Andrea Trianni -  Emanuele Mercanti
# Streamlit application for pyspark machine learning model [code snippet classification]


# Import dependency
import streamlit as st 
import pandas as pd 
import numpy as np 
import seaborn as sns
import matplotlib.pyplot as plt
import json
from io import StringIO

import pyspark
from pyspark.sql import *
from pyspark.sql.types import *
from pyspark.sql.functions import *
from pyspark import SparkContext, SparkConf

from pyspark.ml import Pipeline
from pyspark.ml.feature import CountVectorizer, Tokenizer, RegexTokenizer
from pyspark.ml.feature import HashingTF, CountVectorizer, CountVectorizerModel,IDF, IDFModel
from pyspark.ml.classification import LogisticRegressionModel


# ------------------------------------------------------------------------------


# Get spark session
spark = SparkSession.builder.getOrCreate()

# Loading saved models/pipelines
pipe_lr = LogisticRegressionModel.load("./model.bin")
bow_vectorizer = CountVectorizerModel.load('./pipe/bow_vectorizer.bin')
with open('./pipe/target_dict.json', 'r') as f:
	languages_dict = json.load(f)
languages_dict = {val: key for key, val in languages_dict.items()}


# ------------------------------------------------------------------------------


# encode user input to dataframe
def create_spark_dataframe(input_code):
	return spark.createDataFrame([(1, input_code), ], ["id", "snippet"])

# tokenize and encode the clean dataframe
def transforming_pipeline(df, bow_vectorizer):
	pattern = "([\\n\\t]|([A-Za-z_]+\\b)|[!\#\$%\&\*\+:\-\./<=>\?@\^_\|\~]+|[ \(\),;\{\}\[\]`\"'])"
	tokenizer = RegexTokenizer(inputCol="snippet", outputCol="tokenized", pattern=pattern, gaps=False)
	tokenized_df = tokenizer.transform(df)
	tokenized_df = bow_vectorizer.transform(tokenized_df)
	return tokenized_df

# get prediction from output of the model
def predict_language(pred):
	return pred['prediction'][0]

# get probabilities from output of the model
def get_prediction_proba(pred):
	return pred['probability'][0]

# feed the model
def predict(snippet):
	transformed = pipe_lr.transform(snippet)
	pred = transformed.select('probability','prediction')
	return pred.toPandas()


# ------------------------------------------------------------------------------


# defining the script
def main():

	st.title("Code snippets classification")

	with st.form(key='snippets_clf_form'):
		raw_text = st.text_area("Enter here your snippet..")
		uploaded_file = st.file_uploader("Or choose a file")
		submit_text = st.form_submit_button(label='Submit')

	st.markdown("""---""")
	st.subheader("Query Results:")

	if submit_text:

		if uploaded_file:
			raw_text = StringIO(uploaded_file.getvalue().decode("utf-8")).getvalue()
		
		if len(raw_text)<50:
			st.success("[Exception] Please write a snippet with at least 50 character.")

		else:
			st.success("Original Code:");st.code(raw_text)
			raw_text = create_spark_dataframe(raw_text)
			raw_text = transforming_pipeline(raw_text, bow_vectorizer)
			pred = predict(raw_text)
			prediction = predict_language(pred)
			probability = get_prediction_proba(pred)

			st.success("Tokenized snippet:")
			st.write(str(raw_text.toPandas()["tokenized"][0]))

			st.success("Prediction:")
			st.markdown('The predicted language is: <b>'+str(languages_dict[prediction])+'</b>', unsafe_allow_html=True)
			st.markdown("The probability is: <b>"+ str(np.round(np.max(probability), 4)*100)+"</b>%",unsafe_allow_html=True)

			st.success("Probability:")
			proba_df = pd.DataFrame(data = zip(languages_dict.values(), probability), columns= ["language","probability"] )
			fig, ax = plt.subplots()
			sns.barplot(x='language',y='probability',data=proba_df,palette="mako").set(xlabel=None)
			st.pyplot(fig)


# ------------------------------------------------------------------------------


if __name__ == '__main__':
	main()
